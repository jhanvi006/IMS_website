<?php 
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}

	require_once("classes/dbo.class.php");
	$dlrq = "select * from dealers order by dl_nm";
	$dlrres = $db->get($dlrq);

	$proq = "select * from products";
	$prores = $db->get($proq);

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php require_once("includes/header.inc.php"); ?>
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<?php require_once("includes/logo.inc.php"); ?>	
		</div>
		<div id="menu">
			<?php require_once("includes/menu.inc.php"); ?>
		</div>
	</div>
</div>
</div>
<div id="page" class="container">
	<div class="title">
		<h2>Items</h2>
		<hr class="style18">
	</div>
	<form action="process_add_b_detail.php" method="post" class="form-style-7">
	<table width="100%" border="0" cellspacing="0">
				<tr>
					<td colspan="3">
						<ul>
							<li>
			    				<label for="dlr">Dealers</label>
			    				<select name="dlr">
										<option value="">Select</option>
											<?php
												while($dlrrow = mysqli_fetch_assoc($dlrres)) {
													echo '<option value="'.$dlrrow["dl_id"].'">'.$dlrrow["dl_nm"].'</option>';
												}
											?>
								</select><br>
								<span>Select the dealer</span>
							</li>
						</ul>	
					</td>
				</tr>
				<tr><td colspan="3"></td></tr>
				<tr><td colspan="3"></td></tr>
				<tr><td colspan="3"></td></tr>
				<tr><td colspan="3"></td></tr>
				<tr><td colspan="3"></td></tr>
				<tr>
					<td width="33%"><b>Name</b></td>
					<td width="33%"><b>Quantity</b></td>
					<td width="33%"><b>Rate</b></td>
				</tr>
				<tr><td colspan="3"><hr size="2" color="black" /></td></tr>

				<?php
					while($prorow = mysqli_fetch_assoc($prores)) {
						echo '
								<tr>
									<td>'.$prorow["pro_nm"].'</td>	
									<td>
									<input type="hidden" name="pnm[]" value="'.$prorow["pro_id"].'">

									<input type="text" name="qty[]" size="4" placeholder="qty">
									</td>
									<td>'.$prorow["pro_rate"].'
										<input type="hidden" name="rate[]" value="'.$prorow["pro_rate"].'">
									</td>
								</tr>
								<tr>
								<td colspan="3"><hr size="1" color="#c1c1c1" /></td>
								</tr>
						';
					}	
				?>
				<tr>
					<td colspan=""><b>Discount:</b><input type="text" name="discount" size="4" placeholder="Enter discount here"></td>
					<td><input type="submit" value="Save"></td><td></td>
					</tr>
	</table>
	</form>		

<div id="copyright" class="container">
	<?php require_once("includes/footer.inc.php"); ?>
</div>
</body>
</html>
	