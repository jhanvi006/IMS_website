<?php 
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}

	require_once("classes/dbo.class.php");
	$dlrq = "select * from dealers order by dl_nm";
	$dlrres = $db->get($dlrq);

	if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$dq = "select * from bills where b_dl_id = '".$_POST["dlr"]."'";
		$dres = $db->get($dq);
		$drow = mysqli_fetch_assoc($dres);

		$ddq = "select * from bill_details,products where bd_pro_id = pro_id and bd_b_id = '".$drow["b_id"]."'";
		$ddres = $db->get($ddq);
	}

	

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php require_once("includes/header.inc.php"); ?>
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<?php require_once("includes/logo.inc.php"); ?>	
		</div>
		<div id="menu">
			<?php require_once("includes/menu.inc.php"); ?>
		</div>
	</div>
</div>
</div>
<div id="page" class="container">
	<div class="title">
		<h2>Items</h2>
		<hr class="style18">
	</div>
	<form action="" method="post" class="form-style-7">
	<table width="100%" border="0" cellspacing="0">
				<tr>
					<td colspan="3">
						<ul>
							<li>
			    				<label for="dlr">Dealers</label>
			    				<select name="dlr" class="full_w">
										<option value="">Select</option>
											<?php
												while($dlrrow = mysqli_fetch_assoc($dlrres)) {
													echo '<option value="'.$dlrrow["dl_id"].'">'.$dlrrow["dl_nm"].'</option>';
												}
											?>
								</select><br>
								<span>Select the dealer</span>
							</li>
						</ul>	
					</td>
				</tr>
				
				<tr>
					<td><input type="submit" value="Show"></td><td></td>
				</tr>
	</table>
	</form>		
	<?php  if($_SERVER["REQUEST_METHOD"] == "POST") { ?>
		<table width="100%">
			<tr>
				<td>Date : <?php echo $drow["b_date"] ?></td>
				<td>Discount : <?php echo $drow["b_discount"] ?></td>
				<td></td>
				<td></td>
			</tr>
			<tr>
				<td>Product</td>
				<td>Amount</td>
				<td>Qty</td>
			</tr>
			<?php
				while($ddrow = mysqli_fetch_assoc($ddres))
				{
					echo '
						<tr>
							<td>'.$ddrow["pro_nm"].'</td>
							<td>'.$ddrow["bd_pro_amt"].'</td>
							<td>'.$ddrow["bd_qty"].'</td>
						</tr>
					';
				}
			?>
		</table>
	<?php } ?>
<div id="copyright" class="container">
	<?php require_once("includes/footer.inc.php"); ?>
</div>
</body>
</html>
	