<?php 
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}

	if( ! isset($_GET["dlr_id"]) || ! ctype_digit($_GET["dlr_id"]) ) { header("location: index.php"); exit; }

	require_once("classes/dbo.class.php");
	$dlrq = "select * from dealers order by dl_nm";
	$dlrres = $db->get($dlrq);

	if(mysqli_num_rows($dlrres) == 0) { header("location: index.php"); exit; }

	$dlrrow = mysqli_fetch_assoc($dlrres);

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php require_once("includes/header.inc.php"); ?>
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<?php require_once("includes/logo.inc.php"); ?>	
		</div>
		<div id="menu">
			<?php require_once("includes/menu.inc.php"); ?>
		</div>
	</div>
</div>
</div>
<div id="page" class="container">
	<div id="content">
		<div class="title">
			<h2>Edit Dealer</h2>
			<hr class="style18">
		</div>
		<form action="process_edit_dealer.php" method="post" class="form-style-7">
			<input type="hidden" name="dlr_id" value="<?php echo $dlrrow["dl_id"] ?>">
			
			<ul>
				<li>
    				<label for="dlr_nm">Name</label>
    				<input type="text" name="dlr_nm" value="<?php echo $dlrrow["dl_nm"] ?>">
    				<span>Enter your full name here</span>
				</li>
				<li>
				    <label for="dlr_addr">Address</label>
				    <textarea name="dlr_addr" onkeyup="adjust_textarea(this)"><?php echo $dlrrow["dl_addr"] ?></textarea>
				    <span>Enter your address</span>
				</li>
				<li>
				    <label for="dlr_phn">Phone No.</label>
    				<input type="text" name="dlr_phn" value="<?php echo $dlrrow["dl_phone"] ?>">
    				<span>Enter your contact number here</span>
				</li>
				<li>
				    <label for="dlr_email">Email</label>
				    <input type="email" name="dlr_email" value="<?php echo $dlrrow["dl_email"] ?>">
				    <span>Enter a valid email address</span>
				</li>
				    <input type="submit" value="Update" >
			</ul>
		</form>
	</div>
</div>

<div id="copyright" class="container">
	<?php require_once("includes/footer.inc.php"); ?>
</div>
</body>
</html>
