<?php 
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}

	if( ! isset($_GET["pi_id"]) || ! ctype_digit($_GET["pi_id"]) ) { header("location: index.php"); exit; }

	require_once("classes/dbo.class.php");
	$pitmq = "select * from purchase_items where pitm_id = '".$_GET["pi_id"]."'";
	$pitmres = $db->get($pitmq);

	if(mysqli_num_rows($pitmres) == 0) { header("location: index.php"); exit; }

	$pitmrow = mysqli_fetch_assoc($pitmres);

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php require_once("includes/header.inc.php"); ?>
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<?php require_once("includes/logo.inc.php"); ?>	
		</div>
		<div id="menu">
			<?php require_once("includes/menu.inc.php"); ?>
		</div>
	</div>
</div>
</div>
<div id="page" class="container">
	<div id="content">
		<div class="title">
			<h2>Edit Details</h2>
			<hr class="style18">
		</div>
		<form action="process_edit_pitem.php" method="post" class="form-style-7">
			<input type="hidden" name="pitm_id" value="<?php echo $pitmrow["pitm_id"] ?>">
			
			<ul>
				<li>
    				<label for="pitm_name">Name</label>
    				<input type="text" name="pitm_name" value="<?php echo $pitmrow["pitm_nm"] ?>">
    				<span>Enter purchase item name</span>
				</li>
				<li>
				    <label for="pitm_rate">Rate</label>
    				<input type="text" name="pitm_rate" value="<?php echo $pitmrow["pitm_rate"] ?>">
    				<span>Enter rate for item</span>
				</li>
				    <input type="submit" value="Update" >
			</ul>
		</form>
	</div>
</div>

<div id="copyright" class="container">
	<?php require_once("includes/footer.inc.php"); ?>
</div>
</body>
</html>
