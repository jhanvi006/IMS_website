<?php 
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}
	//print_r($_GET);exit;
	if( ! isset($_GET["proid"]) || ! ctype_digit($_GET["proid"]) ) { header("location: index.php"); exit; }

	require_once("classes/dbo.class.php");
	$catq = "select * from categories order by cat_nm";
	$catres = $db->get($catq);

	$proq = "select * from products,categories where pro_cat_id = cat_id and pro_id ='".$_GET["proid"]."'";
	$prores = $db->get($proq);

	if(mysqli_num_rows($prores) == 0) { header("location: index.php"); exit; }

	$prorow = mysqli_fetch_assoc($prores);

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php require_once("includes/header.inc.php"); ?>
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<?php require_once("includes/logo.inc.php"); ?>	
		</div>
		<div id="menu">
			<?php require_once("includes/menu.inc.php"); ?>
		</div>
	</div>
</div>
</div>
<div id="page" class="container">
	<div id="content">
		<div class="title">
			<h2>Edit Product</h2>
			<hr class="style18">
		</div>
		<form action="process_edit_product.php" method="post" class="form-style-7" enctype="multipart/form-data">
			<input type="hidden" name="pro_id" value="<?php echo $prorow["pro_id"] ?>">
			<input type="hidden" name="pro_pic" value="<?php echo $prorow["pro_pic"] ?>">

			<ul>
				<li>	
				<label for="sp_nm">Category</label>
				<select name="pro" class="full_w">
					<?php
						while($catrow = mysqli_fetch_assoc($catres)) {
							if($catrow["cat_id"] == $prorow["pro_cat_id"])
								echo '<option value="'.$catrow["cat_id"].'" selected="selected">'.$catrow["cat_nm"].'</option>';
							else
								echo '<option value="'.$catrow["cat_id"].'">'.$catrow["cat_nm"].'</option>';
						}
				?>
				</select>
				<span>Select the category for product</span>
				</li>
				<li>
				    <label for="p_nm">Product Name</label>
				    <input type="text" name="p_nm" value="<?php echo $prorow["pro_nm"] ?>">
				    <span>Enter name of the product</span>
				</li>
				<li>
				    <label for="pro_pic">Picture</label>
    				<img src="uploads/<?php  echo $prorow["pro_pic"] ?>" height="100" width="100"> 
    				<span>The picture of product</span>
				</li>
				<li>
				    <label for="p_rate">Rate</label>
				    <input type="text" name="p_rate" value="<?php echo $prorow["pro_rate"] ?>">
				    <span>Enter Rate of the product</span>
				</li>				
				<input type="submit" value="Update">
			</ul>	
		</form>
	</div>
</div>

<div id="copyright" class="container">
	<?php require_once("includes/footer.inc.php"); ?>
</div>
</body>
</html>
