<?php 
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}

	if( ! isset($_GET["sp_id"]) || ! ctype_digit($_GET["sp_id"]) ) { header("location: index.php"); exit; }

	require_once("classes/dbo.class.php");
	$supq = "select * from suppliers order by sup_nm";
	$supres = $db->get($supq);

	if(mysqli_num_rows($supres) == 0) { header("location: index.php"); exit; }

	$suprow = mysqli_fetch_assoc($supres);

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php require_once("includes/header.inc.php"); ?>
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<?php require_once("includes/logo.inc.php"); ?>	
		</div>
		<div id="menu">
			<?php require_once("includes/menu.inc.php"); ?>
		</div>
	</div>
</div>
</div>
<div id="page" class="container">
	<div id="content">
		<div class="title">
			<h2>Edit Supplier</h2>
			<hr class="style18">
		</div>
		<form action="process_edit_supplier.php" method="post" class="form-style-7">
			<input type="hidden" name="sp_id" value="<?php echo $suprow["sup_id"] ?>">
			
			<ul>
				<li>
    				<label for="sp_nm">Name</label>
    				<input type="text" name="sp_nm" value="<?php echo $suprow["sup_nm"] ?>">
    				<span>Enter your full name here</span>
				</li>
				<li>
				    <label for="sp_addr">Address</label>
				    <textarea name="sp_addr" onkeyup="adjust_textarea(this)"><?php echo $suprow["sup_addr"] ?></textarea>
				    <span>Enter your address</span>
				</li>
				<li>
				    <label for="sp_phn">Phone No.</label>
    				<input type="text" name="sp_phn" value="<?php echo $suprow["sup_phone"] ?>">
    				<span>Enter your contact number here</span>
				</li>
				<li>
				    <label for="sp_email">Email</label>
				    <input type="email" name="sp_email" value="<?php echo $suprow["sup_email"] ?>">
				    <span>Enter a valid email address</span>
				</li>
				    <input type="submit" value="Update" >
			</ul>
		</form>
	</div>
</div>

<div id="copyright" class="container">
	<?php require_once("includes/footer.inc.php"); ?>
</div>
</body>
</html>
