-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2017 at 01:42 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ims_mcompany_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ad_id` int(4) NOT NULL,
  `ad_unm` varchar(255) NOT NULL,
  `ad_pwd` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ad_id`, `ad_unm`, `ad_pwd`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE `bills` (
  `b_id` int(4) NOT NULL,
  `b_dl_id` int(4) NOT NULL,
  `b_date` date NOT NULL,
  `b_discount` int(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bills`
--

INSERT INTO `bills` (`b_id`, `b_dl_id`, `b_date`, `b_discount`) VALUES
(1, 1, '2017-03-30', 100),
(2, 3, '2017-04-03', 0),
(3, 1, '2017-04-03', 100),
(4, 0, '2017-04-15', 0),
(5, 0, '2017-04-16', 0),
(6, 0, '2017-04-20', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bill_details`
--

CREATE TABLE `bill_details` (
  `bd_id` int(4) NOT NULL,
  `bd_b_id` int(4) NOT NULL,
  `bd_pro_id` int(4) NOT NULL,
  `bd_pro_amt` int(5) NOT NULL,
  `bd_qty` int(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill_details`
--

INSERT INTO `bill_details` (`bd_id`, `bd_b_id`, `bd_pro_id`, `bd_pro_amt`, `bd_qty`) VALUES
(1, 1, 1, 0, 4),
(2, 1, 2, 0, 7),
(3, 1, 3, 0, 2),
(4, 2, 1, 100, 7),
(5, 2, 2, 100, 9),
(6, 3, 1, 100, 1),
(7, 3, 3, 290, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(4) NOT NULL,
  `cat_nm` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_nm`) VALUES
(17, 'Precision'),
(18, 'Hardware'),
(15, 'Auto'),
(14, 'Sanitary'),
(13, 'Electronic'),
(12, 'Electrical');

-- --------------------------------------------------------

--
-- Table structure for table `dealers`
--

CREATE TABLE `dealers` (
  `dl_id` int(4) NOT NULL,
  `dl_nm` varchar(255) NOT NULL,
  `dl_addr` varchar(255) NOT NULL,
  `dl_phone` varchar(15) NOT NULL,
  `dl_email` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dealers`
--

INSERT INTO `dealers` (`dl_id`, `dl_nm`, `dl_addr`, `dl_phone`, `dl_email`) VALUES
(4, 'Jigar Desai', 'Rajkot', '7545459797', 'jigs@gmail.com'),
(5, 'Sakshi Agrawal', 'Mumbai', '9696969696', 'sakshi_a@yahoo.com');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `fb_id` int(11) NOT NULL,
  `fb_nm` varchar(255) NOT NULL,
  `fb_email` varchar(255) NOT NULL,
  `fb_phone` int(15) NOT NULL,
  `fb_subject` varchar(255) NOT NULL,
  `fb_msg` varchar(255) NOT NULL,
  `fb_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`fb_id`, `fb_nm`, `fb_email`, `fb_phone`, `fb_subject`, `fb_msg`, `fb_date`) VALUES
(1, 'jhanvi', 'jk@google.com', 2147483647, 'regarding product details', 'intererested in the auto products.kindly send its details', '2017-03-31'),
(2, 'satish', 'satish@yahoo.com', 769854098, 'dealer', 'may i get the details abt dealer who has spare products', '2017-04-06');

-- --------------------------------------------------------

--
-- Table structure for table `production_entry`
--

CREATE TABLE `production_entry` (
  `prd_id` int(5) NOT NULL,
  `prd_pro_id` int(5) NOT NULL,
  `prd_qty` int(5) NOT NULL,
  `prd_date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pro_id` int(4) NOT NULL,
  `pro_cat_id` int(4) NOT NULL,
  `pro_nm` varchar(255) NOT NULL,
  `pro_pic` text NOT NULL,
  `pro_rate` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pro_id`, `pro_cat_id`, `pro_nm`, `pro_pic`, `pro_rate`) VALUES
(5, 14, 'Brass sanitary part', '149158852724927_brass_sanitary_part.jpg', 530),
(4, 15, 'Fixtures', '149158830343601_fixtures.jpg', 590);

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `pur_id` int(4) NOT NULL,
  `pur_sup_id` int(11) NOT NULL,
  `pur_date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`pur_id`, `pur_sup_id`, `pur_date`) VALUES
(1, 4, '2017-03-30');

-- --------------------------------------------------------

--
-- Table structure for table `purchase_details`
--

CREATE TABLE `purchase_details` (
  `purd_id` int(4) NOT NULL,
  `purd_pur_id` int(4) NOT NULL,
  `purd_pitm_id` int(4) NOT NULL,
  `purd_pitm_amt` int(11) NOT NULL,
  `purd_qty` int(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_details`
--

INSERT INTO `purchase_details` (`purd_id`, `purd_pur_id`, `purd_pitm_id`, `purd_pitm_amt`, `purd_qty`) VALUES
(1, 1, 1, 876, 10),
(2, 1, 3, 55, 12);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_items`
--

CREATE TABLE `purchase_items` (
  `pitm_id` int(4) NOT NULL,
  `pitm_nm` varchar(255) NOT NULL,
  `pitm_rate` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchase_items`
--

INSERT INTO `purchase_items` (`pitm_id`, `pitm_nm`, `pitm_rate`) VALUES
(1, 'Clock', 876),
(3, 'Pipe', 550),
(4, 'Tap', 675);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `sup_id` int(4) NOT NULL,
  `sup_nm` varchar(255) NOT NULL,
  `sup_addr` varchar(255) NOT NULL,
  `sup_phone` varchar(15) NOT NULL,
  `sup_email` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`sup_id`, `sup_nm`, `sup_addr`, `sup_phone`, `sup_email`) VALUES
(4, 'Tata', 'japan', '8787878787', 'tata@yahoo.com'),
(5, 'Anaksh', 'Antartica', '9898989898', 'ana@ana.com'),
(9, 'Sonia Baxi', '\r\nAhmedabad.', '7676676567', 'sonia@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ad_id`);

--
-- Indexes for table `bills`
--
ALTER TABLE `bills`
  ADD PRIMARY KEY (`b_id`),
  ADD KEY `b_dl_id` (`b_dl_id`);

--
-- Indexes for table `bill_details`
--
ALTER TABLE `bill_details`
  ADD PRIMARY KEY (`bd_id`),
  ADD KEY `bd_pro_amt` (`bd_pro_amt`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `dealers`
--
ALTER TABLE `dealers`
  ADD PRIMARY KEY (`dl_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`fb_id`);

--
-- Indexes for table `production_entry`
--
ALTER TABLE `production_entry`
  ADD PRIMARY KEY (`prd_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pro_id`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`pur_id`);

--
-- Indexes for table `purchase_details`
--
ALTER TABLE `purchase_details`
  ADD PRIMARY KEY (`purd_id`);

--
-- Indexes for table `purchase_items`
--
ALTER TABLE `purchase_items`
  ADD PRIMARY KEY (`pitm_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`sup_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `ad_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `bills`
--
ALTER TABLE `bills`
  MODIFY `b_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `bill_details`
--
ALTER TABLE `bill_details`
  MODIFY `bd_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `dealers`
--
ALTER TABLE `dealers`
  MODIFY `dl_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `fb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `production_entry`
--
ALTER TABLE `production_entry`
  MODIFY `prd_id` int(5) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `pro_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `pur_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `purchase_details`
--
ALTER TABLE `purchase_details`
  MODIFY `purd_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `purchase_items`
--
ALTER TABLE `purchase_items`
  MODIFY `pitm_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `sup_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
