<ul>
	<li><a href="index.php" title="">DashBoard</a></li>
	<li><a href="logout.php" title="">Logout</a></li>
</ul>