<?php
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php require_once("includes/header.inc.php"); ?>
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<?php require_once("includes/logo.inc.php"); ?>	
		</div>
		<div id="menu">
			<?php require_once("includes/menu.inc.php"); ?>
		</div>
	</div>
</div>
</div>
<div id="page" class="container">
	<div id="content">
		<table cellspacing='0' valign="center" class="index"> 
			<tbody>
				<tr>
					<td><a href="categories.php" title="">Categories</a></td>
					<td><a href="products.php" title="">Products</a></td>
					<td><a href="purchases.php" title="">Purchases</a></td>
				</tr>
				<tr>
					<td><a href="dealers.php" title="">Dealers</a></td>
					<td><a href="suppliers.php" title="">Suppliers</a></td>
					<td><a href="purchase_itm.php" title="">Product Details</a></td>
				</tr>
				<tr>
					<td><a href="bills.php" title="">Purchase Item</a></td>
					<td><a href="disp_bills.php" title="">Bill</a></td>
					<td><a href="v_feedback.php" title="">View Feedback</a></td>
				</tr>
			</tbody>
		</table>
	</div>	
</div>

<div id="copyright" class="container">
	<?php require_once("includes/footer.inc.php"); ?>
</div>
</body>
</html>
