<?php
	session_start();
		
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php require_once("includes/header.inc.php"); ?>
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<?php require_once("includes/logo.inc.php"); ?>	
		</div>
		<div id="menu">
				
		</div>
	</div>
</div>
</div>
<div id="page" class="container">
	<div id="content">
		<div class="title">
			<h2>LOGIN</h2>
			<hr class="style18">
		</div>
		<form action="process_login.php" method="post" class="form-style-7">
			<ul>
				<li>
    				<label for="u_nm">User Name</label>
    				<input type="text" name="unm">
    				<span>Enter your full name here</span>
				</li>
				<li>
				    <label for="pwd">Password</label>
    				<input type="password" name="pwd">
    				<span>Enter your password here</span>
				</li>
				    <input type="submit" value="Login" >
			</ul>
		</form>
	</div>
</div>		

<div id="copyright" class="container">
	<?php require_once("includes/footer.inc.php"); ?>
</div>
</body>
</html>
