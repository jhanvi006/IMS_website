<?php
	session_start();

	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}

	unset($_SESSION["adid"]);

	header("location:../index.php");

?>