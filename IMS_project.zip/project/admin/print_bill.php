<?php
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}
		
	require_once("classes/dbo.class.php");
	$q = "select *,date_format(b_date, '%d %b %Y') as date from bills, dealers where b_dl_id = dl_id and b_id='".$_GET["bid"]."'";
	$res = $db->get($q);
	$row = mysqli_fetch_assoc($res);

	

	$bq = "select * from bill_details,products where bd_pro_id = pro_id and bd_b_id = '".$_GET["bid"]."'";
	$bres =$db->get($bq);

	$total = 0;

?><!DOCTYPE html>
<html>
<head>
	<title>Retail Bill</title>
</head>
<body>
	<table border="1" align="center" width="800px"> 
		<tr>
			<td width="300px" height="50px">logo</td>
			<td width="500px">
			<table border="0">
				<tr>
					<td width="250px" height="50px" valign="top">
					Invoice No : <b>INVO<?php echo rand(1000,9999); ?></b></td>
					<td width="250px" height="50px" valign="top">
					Date : <b><?php echo $row["date"]; ?></b>
					</td>
				</tr>
							
				<tr>
					<td width="250px" height="50px" valign="top">Terms of payment</td>
					<td width="250px" height="50px" valign="top">7 days</td>
				</tr>
			</table>
			</td>
		</tr>
		<tr>
			<td width="300px" height="80px" valign="top">
				<b>Customer Details</b><br>
				Name : <?php echo $row["dl_nm"]; ?><br>
				Phone : <?php echo $row["dl_phone"]; ?><br>	
				Address : <?php echo $row["dl_addr"]; ?><br>	
			</td>
			<td width="500px">
			<table border="0">
				<tr>
					<td width="250px" height="50px" valign="top">Payment Type</td>
					<td width="250px" height="50px" valign="top">Cheque No</td>
				</tr>
				<tr>
					<td colspan="2" width="250px" height="50px" valign="top">Terms of delivery</td>
				</tr>
			</table>
			</td>
		</tr>
		<tr>
			<td colspan="2">
			<table border="0" width="800px">
				<tr>
					<td width="30px">No.</td>
					<td width="550px">Item name</td>
					<td width="85px">Qty</td>
					<td width="85px">Rate</td>
					<td width="150px">Value</td>
				</tr>
				<tr>
					<td colspan="5"><hr></td>
				</tr>
				<tr>
					<td>
						<?php 
							$i = 1;

							while ($brow=mysqli_fetch_assoc($bres)) {
								$val = ($brow["bd_pro_amt"] * $brow["bd_qty"]);
								$total += $val;

								echo '
									<tr>
										<td>'.$i.'</td>
										<td>'.$brow["pro_nm"].'</td>
										<td>'.$brow["bd_qty"].'</td>
										<td>'.$brow["bd_pro_amt"].'</td>
										<td>'.$val.'</td>
									</tr>
								';
							}
							$i++;
						?>
					</td>
				</tr>
				<tr>
					<td colspan="5"><hr></td>
				</tr>
				<tr>
					<td colspan="4" align="right">Total</td>
					<td><?php echo $total; ?></td>
				</tr>
				<tr>
					<td colspan="5"><hr></td>
				</tr>
			</table>
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<table width="800px" border="0">
					<tr>
						<td height="60px" valign="bottom" width="400px">
							<font size="2">
							Company's CST No: 24132004572 24/04/2005 <br>
							Company's Tin No: 24092405207 30/03/2005 <br>
							Bank Account No: 09972000009601 - HDFC Bank Rajkot
							</font>
						</td>
						<td>
							<table border="0" width="400px" >
								<tr>
									<td width="200px"><font size="2"> Discount: </font>
									</td>
									<td width="100px">
										<?php echo $row["b_discount"]; ?>
									</td>
									
								</tr>
								<tr>
									<td><font size="2">Net Value:</font></td>
									<td>
										<?php echo $total - $row["b_discount"]; ?>
									</td>
									
								</tr>
								<tr>
									<td><font size="2">VAT/CST:</font></td>
									<td>0</td>
								</tr>
								<tr>
									<td><font size="2">Additional tax:</font></td>
									<td>0</td>
								</tr>
								<tr>
									<td><font size="2">Again C form:</font></td>
									<td>0</td>
									
								</tr>
								<tr>
									<td><font size="2">Total:</font></td>
									<td><?php echo $total - $row["b_discount"]; ?></td>
								</tr>
								<tr>
									<td><font size="2">Freight charge:</font></td>
									<td>0</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<table width="800px" border="0">
					<tr>
						<td height="60px" width="400px">
							<font size="2"><b>Declaration</b></font><br>
						</td>
						<td>
							<table width="400px" border="0">
								<tr>
									<td><b>Final Invoice Value:</b></td>
									<td><?php echo $total - $row["b_discount"]; ?></td>
								</tr>
								<tr>
									<td colspan="2"><hr></td>
								</tr>
								<tr>
									<td colspan="2" valign="top">
									<font size="2">Date and time of invoice:</font> : <?php echo $row["date"]; ?>
									</td>
								</tr>
								<tr>
									<td align="right" colspan="2">
									<font size="2">Authorized Signatory</font>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>