<?php
		session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}
	
		require_once('classes/dbo.class.php');

		$q = "insert into bills(b_dl_id, b_date, b_discount)values('".$_POST["dlr"]."','".date('Y-m-d')."','".$_POST["discount"]."')";

		$id = $db->dml($q);


		for($i=0;$i<=count($_POST['qty']);$i++)
		{
			if($_POST['qty'][$i] == ""){continue;}
			$q = "insert into bill_details(bd_b_id,bd_pro_id,bd_pro_amt,bd_qty)values('".$id."','".$_POST["pnm"][$i]."','".$_POST["rate"][$i]."','".$_POST["qty"][$i]."')";
			$db->dml($q);
		}

		header("location:print_bill.php?bid=".$id);			
?>