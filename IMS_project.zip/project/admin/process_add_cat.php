<?php

	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}
		
	if(empty($_POST)) { header("location: index.php"); exit; }

	$errors = array();

	if(empty($_POST["cat_name"]))
		$errors[] = "Category name was empty!";

	if( ! empty($errors) ) {
		echo "<b>Error(s):</b><hr />";
		foreach($errors as $e) {
			echo $e."<br />";
		}
		exit;
	}

	require_once("classes/dbo.class.php");
	$q = "insert into categories (cat_nm) values ('".$_POST["cat_name"]."')";
	$db->dml($q);

	header("location: categories.php"); 
?>