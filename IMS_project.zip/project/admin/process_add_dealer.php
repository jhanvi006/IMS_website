<?php
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}
	
	if(empty($_POST)) { header("location: index.php"); exit; }

	$errors = array();

	//General Validation

	if(empty($_POST["dlr_nm"]))
		$errors[] = "Name was empty!";

	if(empty($_POST["dlr_addr"]))
		$errors[] = "Address was empty!";

	if(empty($_POST["dlr_phn"]))
		$errors[] = "Phone was empty!";
	if( ! ctype_digit($_POST["dlr_phn"]) || strlen($_POST["dlr_phn"]) != 10)
		$errors[] = "Phone must be valid 10 digits!";

	if(empty($_POST["dlr_email"]))
		$errors[] = "Email was empty!";


	//Show Errors, If Any

	if( ! empty($errors) ) {
		echo "<b>Error(s):</b><hr />";
		foreach($errors as $e) {
			echo $e."<br />";
		}
		exit;
	}


	//Data Entry
	require_once("classes/dbo.class.php");
	$q = "insert into dealers(dl_nm, dl_addr, dl_phone, dl_email) values('".$_POST["dlr_nm"]."','".$_POST["dlr_addr"]."','".$_POST["dlr_phn"]."','".$_POST["dlr_email"]."')";
	$db->dml($q);

	header("location: dealers.php"); 
?>