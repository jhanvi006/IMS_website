<?php
		session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}
	
		require_once('classes/dbo.class.php');

		$q = "insert into purchases(pur_sup_id,pur_date)values('".$_POST["sup"]."','".date('Y-m-d')."')";

		$id = $db->dml($q);


		for($i=0;$i<=count($_POST['qty']);$i++)
		{
			if($_POST['qty'][$i] == ""){continue;}
			$q = "insert into purchase_details(purd_pur_id,purd_pitm_id,purd_pitm_amt,purd_qty)values('".$id."','".$_POST["pnm"][$i]."','".$_POST["rate"][$i]."','".$_POST["qty"][$i]."')";
			$db->dml($q);
		}

		header("location:purchases.php");				
?>