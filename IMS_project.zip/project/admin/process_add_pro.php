<?php
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}
	
	if(empty($_POST)) { header("location: index.php"); exit; }

	$errors = array();

	//General Validation

	if(empty($_POST["pro"]))
		$errors[] = "Category was empty!";

	if(empty($_POST["pro_nm"]))
		$errors[] = "Name was empty!";

	if(empty($_POST["pro_rate"]))
		$errors[] = "Rate was empty!";

	
	//File Validation
	if( ! empty($_FILES["pro_pic"]["name"])) {

		if( $_FILES["pro_pic"]["error"] != 0 ) 
			$errors[] = "Error uploading picture! Try again later.";

		$ext = pathinfo($_FILES["pro_pic"]["name"], PATHINFO_EXTENSION);

		if( ! ($ext == "jpg" || $ext == "jpeg" ))
			$errors[] = "Picture must be jpg file.";

	} else {
		$errors[] = "Picture was empty!";
	}


	//Show Errors, If Any

	if( ! empty($errors) ) {
		echo "<b>Error(s):</b><hr />";
		foreach($errors as $e) {
			echo $e."<br />";
		}
		exit;
	}


	//File Upload
	$fnm = time().rand(10000,99999)."_".$_FILES["pro_pic"]["name"];	
	move_uploaded_file($_FILES["pro_pic"]["tmp_name"], "uploads/".$fnm);


	//Data Entry
	require_once("classes/dbo.class.php");
	$q = "insert into products(pro_cat_id, pro_nm, pro_pic, pro_rate) values('".$_POST["pro"]."','".$_POST["pro_nm"]."','".$fnm."','".$_POST["pro_rate"]."')";
	$db->dml($q);

	header("location: products.php"); 
?>