<?php 
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}

	require_once("classes/dbo.class.php");
	$dlrq = "select * from dealers,bills where b_dl_id=dl_id order by dl_nm";
	$dlrres = $db->get($dlrq);

	$proq = "select * from products";
	$prores = $db->get($proq);

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php require_once("includes/header.inc.php"); ?>
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<?php require_once("includes/logo.inc.php"); ?>	
		</div>
		<div id="menu">
			<?php require_once("includes/menu.inc.php"); ?>
		</div>
	</div>
</div>
</div>
<div id="page" class="container">
	<div class="title">
		<h2>Items</h2>
		<hr class="style18">
	</div>
	<table width="100%" border="0" cellspacing="0">
				<tr>
					<td width="33%"><b>Date</b></td>
					<td width="33%"><b>Discount</b></td>
				</tr>
				<tr><td colspan="3"><hr size="2" color="black" /></td></tr>

				<?php
					while($dlrrow = mysqli_fetch_assoc($dlrres)) {
						echo '
								<tr>
									<td>'.$dlrrow["b_date"].'</td>
									<td>'.$dlrrow["b_discount"].'</td>
								</tr>
								<tr>
								<td colspan="3"><hr size="1" color="#c1c1c1" /></td>
								</tr>
						';
					}	
				?>
	</table>	

<div id="copyright" class="container">
	<?php require_once("includes/footer.inc.php"); ?>
</div>
</body>
</html>
	