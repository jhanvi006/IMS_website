<?php
	
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}
	
	if( ! isset($_GET["cat_id"]) || ! ctype_digit($_GET["cat_id"])) { header("location: index.php"); exit; }

	require_once("classes/dbo.class.php");

	$q = "delete from categories where cat_id = '".$_GET["cat_id"]."'";
	$db->dml($q);

	header("location: categories.php");	
?>