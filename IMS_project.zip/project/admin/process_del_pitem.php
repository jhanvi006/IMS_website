<?php
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}

	if( ! isset($_GET["pi_id"]) || ! ctype_digit($_GET["pi_id"])) { header("location: index.php"); exit; }

	require_once("classes/dbo.class.php");

	$q = "delete from purchase_items where pitm_id = '".$_GET["pi_id"]."'";
	$db->dml($q);

	header("location: purchase_itm.php");	
?>