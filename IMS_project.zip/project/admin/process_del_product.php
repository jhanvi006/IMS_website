<?php
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}
	
	if( ! isset($_GET["pro_id"]) || ! ctype_digit($_GET["pro_id"])) { header("location: index.php"); exit; }

	require_once("classes/dbo.class.php");

	$q = "delete from products where pro_id = '".$_GET["pro_id"]."'";
	$db->dml($q);

	header("location: products.php");	
?>