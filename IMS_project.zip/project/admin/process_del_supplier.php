<?php
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}
	
	if( ! isset($_GET["sup_id"]) || ! ctype_digit($_GET["sup_id"])) { header("location: index.php"); exit; }

	require_once("classes/dbo.class.php");

	$q = "delete from suppliers where sup_id = '".$_GET["sup_id"]."'";
	$db->dml($q);

	header("location: suppliers.php");	
?>