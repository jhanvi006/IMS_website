<?php
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}
	
	if(empty($_POST)) { header("location: index.php"); exit; }

	$errors = array();

	//General Validation

	if(empty($_POST["pitm_name"]))
		$errors[] = "Name was empty!";

	if(empty($_POST["pitm_rate"]))
		$errors[] = "Rate was empty!";

	//Show Errors, If Any

	if( ! empty($errors) ) {
		echo "<b>Error(s):</b><hr />";
		foreach($errors as $e) {
			echo $e."<br />";
		}
		exit;
	}


	//Data Entry
	require_once("classes/dbo.class.php");
	$q = "update purchase_items set pitm_nm='".$_POST["pitm_name"]."', pitm_rate='".$_POST["pitm_rate"]."' where pitm_id = '".$_POST["pitm_id"]."'";
	$db->dml($q);

	header("location: purchase_itm.php"); 
?>