<?php
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}
	
	if(empty($_POST)) { header("location: index.php"); exit; }

	$errors = array();

	//General Validation

	if(empty($_POST["pro"]))
		$errors[] = "Category was empty!";

	if(empty($_POST["p_nm"]))
		$errors[] = "Name was empty!";

	if(empty($_POST["p_rate"]))
		$errors[] = "Rate was empty!";

	//Show Errors, If Any

	if( ! empty($errors) ) {
		echo "<b>Error(s):</b><hr />";
		foreach($errors as $e) {
			echo $e."<br />";
		}
		exit;
	}




	//Data Entry
	require_once("classes/dbo.class.php");
	$q = "update products set pro_cat_id='".$_POST["pro"]."', pro_nm='".$_POST["p_nm"]."', pro_rate='".$_POST["p_rate"]."'  where  pro_id = '".$_POST["pro_id"]."'";
	$db->dml($q);

	header("location: products.php"); 
?>