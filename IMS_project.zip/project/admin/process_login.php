<?php

	session_start();
	
		
	if(empty($_POST)) { header("location: index.php"); exit; }

	$errors = array();

	if(empty($_POST["unm"]))
		$errors[] = "Username was empty!";
	if(empty($_POST["pwd"]))
		$errors[] = "Password was empty!";

	if( ! empty($errors) ) {
		echo "<b>Error(s):</b><hr />";
		foreach($errors as $e) {
			echo $e."<br />";
		}
		exit;
	}

	require_once("classes/dbo.class.php");
	$q = "select * from admin where ad_unm = '".$_POST["unm"]."' and ad_pwd = '".$_POST["pwd"]."'";
	$res = $db->get($q);

	if(mysqli_num_rows($res) != 0)
	{
		$row = mysqli_fetch_assoc($res);

		$_SESSION["adid"] = $row["ad_id"];

		header("location: index.php");
		exit;
	}
	else
	{
		echo 'Invalid username Or Password';
	}

?>