<?php session_start();

	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}

	require_once("classes/dbo.class.php");
	$pitmq = "select * from purchase_items order by pitm_nm";
	$pitmres = $db->get($pitmq);

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php require_once("includes/header.inc.php"); ?>
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<?php require_once("includes/logo.inc.php"); ?>	
		</div>
		<div id="menu">
			<?php require_once("includes/menu.inc.php"); ?>
		</div>
	</div>
</div>
</div>
<div id="page" class="container">
	<div id="content">
		<div class="title">
			<h2>Add Item Details</h2>
			<hr class="style18">
	</div>
	<form action="process_add_pitem.php" method="post" class="form-style-7">
        	<ul>
       			<li>
				    <label for="pitm_name">Name</label>
				    <input type="text" name="pitm_name">
				    <span>Enter purchase item name</span>
				</li>
				<li>
				    <label for="pitm_rate">Rate</label>
				    <input type="text" name="pitm_rate">
				    <span>Enter rate for item</span>
				</li>
				    <input type="submit" value=" OK " >
			</ul>
	</form>

	<br /><br />
	<div class="title">
		<h2>Display Item Details</h2>
		<hr class="style18">
	</div>
	<table width="100%" border="0" cellpadding="3">
		<tr>
			<td width="33%"><b>Name</b></td>
			<td width="33%"><b>Rate</b></td>
			<td width="33%"></td>
		</tr>
		<tr><td colspan="3"><hr size="2" color="black" /></td></tr>
				<?php
					while($pitmrow = mysqli_fetch_assoc($pitmres)) {
						echo '
								<tr>
									<td>'.$pitmrow["pitm_nm"].'</td>
									<td>'.$pitmrow["pitm_rate"].'</td>									
									<td>
										<a href="edit_pitem.php?pi_id='.$pitmrow["pitm_id"].'" class="edit_link">Edit</a> &nbsp;
										<a href="process_del_pitem.php?pi_id='.$pitmrow["pitm_id"].'" class="del_link">Delete
										</a> 
									</td>
								</tr>
								<tr><td colspan="3"><hr size="1" color="#c1c1c1" /></td></tr>
						';
					}
				?>
	</table>
</div>

<div id="copyright" class="container">
	<?php require_once("includes/footer.inc.php"); ?>
</div>
</body>
</html>
