<?php 
session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}

	require_once("classes/dbo.class.php");
	$supq = "select * from suppliers order by sup_nm";
	$supres = $db->get($supq);

	$pitmq = "select * from purchase_items";
	$pitmres = $db->get($pitmq);

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php require_once("includes/header.inc.php"); ?>
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<?php require_once("includes/logo.inc.php"); ?>	
		</div>
		<div id="menu">
			<?php require_once("includes/menu.inc.php"); ?>
		</div>
	</div>
</div>
</div>
<div id="page" class="container">
	<div class="title">
		<h2>Items</h2>
		<hr class="style18">
	</div>
	<form action="process_add_detail.php" method="post" class="form-style-7">
	<table width="100%" border="0" cellspacing="0">
				<tr>
					<td colspan="3">
						<ul>
							<li>
			    				<label for="pur">Suppliers</label>
			    				<select name="sup" class="full_w">
										<option value="">Select</option>
											<?php
												while($suprow = mysqli_fetch_assoc($supres)) {
													echo '<option value="'.$suprow["sup_id"].'">'.$suprow["sup_nm"].'</option>';
												}
											?>
								</select><br>
								<span>Select the supplier</span>
							</li>
						</ul>	
					</td>
				</tr>
				<tr>
					<td width="33%"><b>Name</b></td>
					<td width="33%"><b>Quantity</b></td>
					<td width="33%"><b>rate</b></td>
				</tr>
				<tr><td colspan="3"><hr size="2" color="black" /></td></tr>

				<?php
					while($pitmrow = mysqli_fetch_assoc($pitmres)) {
						echo '
								<tr>
									<td>'.$pitmrow["pitm_nm"].'</td>
									<td>
									<input type="hidden" name="pnm[]" value="'.$pitmrow["pitm_id"].'">

									<input type="text" name="qty[]" size="4">
									</td>	
									<td>'.$pitmrow["pitm_rate"].'
										<input type="hidden" name="rate[]" value="'.$pitmrow["pitm_rate"].'">
									</td>
								</tr>
								<tr><td colspan="4"><hr size="1" color="#c1c1c1" /></td></tr>
						';
					}
					echo '<tr><td></td><td colspan="3"><input type="submit" value="Save"></td><td></td></tr>';
				?>
	</table>
	</form>		

<div id="copyright" class="container">
	<?php require_once("includes/footer.inc.php"); ?>
</div>
</body>
</html>
