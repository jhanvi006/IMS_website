<?php 
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}

	require_once("classes/dbo.class.php");
	$supq = "select * from suppliers order by sup_nm";
	$supres = $db->get($supq);

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php require_once("includes/header.inc.php"); ?>
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<?php require_once("includes/logo.inc.php"); ?>	
		</div>
		<div id="menu">
			<?php require_once("includes/menu.inc.php"); ?>
		</div>
	</div>
</div>
</div>
<div id="page" class="container">
	<div id="content">
		<div class="title">
			<h2>Add Suppliers</h2>
			<hr class="style18">
		</div>
		<form action="process_add_supplier.php" method="post" class="form-style-7">
			<ul>
				<li>
    				<label for="sp_nm">Name</label>
    				<input type="text" name="sp_nm">
    				<span>Enter your full name here</span>
				</li>
				<li>
				    <label for="sp_addr">Address</label>
				    <textarea name="sp_addr" onkeyup="adjust_textarea(this)"></textarea>
				    <span>Enter your address</span>
				</li>
				<li>
				    <label for="sp_phn">Phone No.</label>
    				<input type="text" name="sp_phn">
    				<span>Enter your contact number here</span>
				</li>
				<li>
				    <label for="sp_email">Email</label>
				    <input type="email" name="sp_email">
				    <span>Enter a valid email address</span>
				</li>
				    <input type="submit" value=" Add " >
			</ul>
		</form>
	</div>
	<br /><br />
			<div class="title">
				<h2>List of Suppliers</h2>
				<hr class="style18">
			</div>
			<table width="100%" border="0" cellspacing="0">
				<tr>
					<td width="20%"><b>Name</b></td>
					<td width="20%"><b>Address</b></td>
					<td width="20%"><b>Phone no.</b></td>
					<td width="20%"><b>Email</b></td>
					<td width="20%"></td>
				</tr>
				<tr><td colspan="5"><hr size="2" color="black" /></td></tr>
				<?php
					while($suprow = mysqli_fetch_assoc($supres)) {
						echo '
								<tr>
									<td>'.$suprow["sup_nm"].'</td>
									<td>'.$suprow["sup_addr"].'</td>
									<td>'.$suprow["sup_phone"].'</td>
									<td>'.$suprow["sup_email"].'</td>
									
									<td>
										<a href="edit_supplier.php?sp_id='.$suprow["sup_id"].'" class="edit_link">Edit</a> &nbsp;
										<a href="process_del_supplier.php?sp_id='.$suprow["sup_id"].'" class="del_link">Delete
										</a> 
									</td>
								</tr>
								<tr><td colspan="5"><hr size="1" color="#c1c1c1" /></td></tr>
						';
					}
				?>
			</table>

<div id="copyright" class="container">
	<?php require_once("includes/footer.inc.php"); ?>
</div>
</body>
</html>
