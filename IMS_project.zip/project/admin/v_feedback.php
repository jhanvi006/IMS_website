<?php
	session_start();
	if(!isset($_SESSION["adid"]))
	{
		header("location:login.php");
		exit;
	}
	require_once("classes/dbo.class.php");
	$fbq = "select * from feedback order by fb_date";
	$fbres = $db-> get($fbq);

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php require_once("includes/header.inc.php"); ?>
</head>
<body>
<div id="header-wrapper">
	<div id="header" class="container">
		<div id="logo">
			<?php require_once("includes/logo.inc.php"); ?>	
		</div>
		<div id="menu">
			<?php require_once("includes/menu.inc.php"); ?>
		</div>
	</div>
</div>
</div>
<div id="page" class="container">
	<div id="content">
	<div class="title">
				<h2>Feedback</h2>
				<hr class="style18">
	</div>
		<table width="100%" border="0" cellspacing="0">
				<tr>
					<td width="16%"><b>Name</b></td>
					<td width="16%"><b>Email</b></td>
					<td width="16%"><b>Phone no.</b></td>
					<td width="16%"><b>Subject</b></td>
					<td width="16%"><b>Message</b></td>
					<td width="16%"><b>Date</b></td>
				</tr>
				<tr><td colspan="6"><hr size="2" color="black" /></td></tr>
				<?php
					while($fbrow = mysqli_fetch_assoc($fbres)) {
						echo '
								<tr>
									<td>'.$fbrow["fb_nm"].'</td>
									<td>'.$fbrow["fb_email"].'</td>
									<td>'.$fbrow["fb_phone"].'</td>
									<td>'.$fbrow["fb_subject"].'</td>
									<td>'.$fbrow["fb_msg"].'</td>
									<td>'.$fbrow["fb_date"].'</td>
									
								</tr>
								<tr><td colspan="6"><hr size="1" color="#c1c1c1" /></td></tr>
						';
					}
				?>
			</table>
	</div>	
</div>

<div id="copyright" class="container">
	<?php require_once("includes/footer.inc.php"); ?>
</div>
</body>
</html>
