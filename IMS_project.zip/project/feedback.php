<?php 

	require_once("classes/dbo.class.php");
	$catq = "select * from categories order by cat_nm";
	$catres = $db->get($catq);

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
		<?php require_once("includes/header.inc.php"); ?>
    </head>
    <body>
		<div id="bg">
			<div id="outer">
				<div id="header">
					<div id="logo">
						<h1>
							<?php require_once("includes/logo.inc.php"); ?>
						</h1>
					</div>
					<div id="nav">
						<?php require_once("includes/menu.inc.php"); ?>
						<br class="clear" />
					</div>
				</div>
				
				<div id="main">
					<div id="sidebar">
						<?php require_once("includes/sidebar.inc.php"); ?>	
					</div>
					<div id="content">
						<div id="box1">
							
							<form action="process_fb.php" method="post">
	    						<h1>Please do not hesitate for asking queries and sharing experience!</h1>
	    
    							<div class="contentform">
    								<div id="sendmessage"> Your message has been sent successfully. Thank you. </div>

								<div class="leftcontact"> 

            						<div class="form-group">
            							<p>Name <span>*</span></p>
            							<span class="icon-case"><i></i></span>
										<input type="text" name="nm"/>
                						<div class="validation"></div>
									</div>

									<div class="form-group">
										<p>E-mail <span>*</span></p>	
										<span class="icon-case"></span>
                						<input type="email" name="email" />
                						<div class="validation"></div>
									</div>

									<div class="form-group">
										<p>Phone number <span>*</span></p>	
										<span class="icon-case"></span>
										<input type="text" name="phone"/>
                						<div class="validation"></div>
									</div>
								</div>

								<div class="rightcontact">

									<div class="form-group">
										<p>Subject <span>*</span></p>	
										<span class="icon-case"></span>
                						<input type="text" name="sub"/>
                						<div class="validation"></div>
									</div>
		
									<div class="form-group">
										<p>Message <span>*</span></p>
										<span class="icon-case"></span>
                						<textarea name="msg" rows="14"></textarea>
                						<div class="validation"></div>
									</div>	
								</div>
							</div>
							<button type="submit" class="button-contact">Send</button>
						</form>	
						</div>
						
						<br class="clear" />
					</div>
					<br class="clear" />
				</div>
			</div>
			<div id="copyright">
				<?php require_once("includes/footer.inc.php"); ?>
			</div>
		</div>
    </body>
</html>
