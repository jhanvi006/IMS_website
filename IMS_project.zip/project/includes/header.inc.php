<title>My Project</title>
<link href="http://fonts.googleapis.com/css?family=Bitter" rel="stylesheet" type="text/css" />
<!--link rel="stylesheet" type="text/css" href="style.css" />

/*************************** Custom ****************************/

<!-- link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css" -->


<!-- link rel="stylesheet" type="text/css" href="engine1/style.css" /-->
<!--script type="text/javascript" src="engine1/jquery.js"></script-->

<link href="style.css" type="text/css" rel="stylesheet">
<script type="text/javascript" src="jquery.js"></script>

	<link href="bjqs.css" rel="stylesheet" type="text/css" media="screen" />
	<script type="text/javascript" src="bjqs-1.3.min.js"></script>


	<script type="text/javascript">
		$(document).ready(function() {
			
		$('#my_slider').bjqs({
			animtype      : 'fade',
			height        : 320,
			width         : 620,
			responsive    : true,
			randomstart   : true
		});

		})
	</script>