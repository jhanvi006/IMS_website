<ul>
	<li>
		<a href="index.php"><img src="images/home.png" align="center"/> &nbsp; Home </a>
	</li>
	<li>
		<a href="feedback.php"><img src="images/_contact.png" align="center"/> &nbsp;Contact</a>
	</li>
</ul>