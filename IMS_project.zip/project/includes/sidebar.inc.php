<?php
	require_once("classes/dbo.class.php");

	$catq = "select * from categories order by cat_nm";
	$catres = $db->get($catq);
?>
<h3>
	<b><img src="images/categories.png" align="center"/>&nbsp;Categories</b><br><br>
		<table align="center">
			<?php
				while($catrow = mysqli_fetch_assoc($catres)) {
					echo '
						<tr>
							<td><a href="disp_products.php?cid='.$catrow["cat_id"].'"><img src="images/bullet.png" align="center"/>&nbsp;'.$catrow["cat_nm"].'</a></td>
						</tr>
						';
				}
			?>
		</table>
</h3>