<div id="my_slider">
        <ul class="bjqs">
            <li><img src="images/auto.jpg" title="auto brass"></li>
            <li><img src="images/hardware.jpg" title="hardware"></li>
            <li><img src="images/sanatary.jpg" title="sanatary"></li>
            <li><img src="images/precision.jpg" title="precision"></li>
        </ul>
</div>