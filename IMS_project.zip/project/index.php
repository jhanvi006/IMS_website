<?php 

	require_once("classes/dbo.class.php");
	$catq = "select * from categories order by cat_nm";
	$catres = $db->get($catq);

	$proq = "select * from products,categories where pro_cat_id = cat_id order by pro_nm";
	$prores = $db->get($proq);

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
		<?php require_once("includes/header.inc.php"); ?>
    </head>
    <body>
		<div id="bg">
			<div id="outer">
				<div id="header">
					<div id="logo">
						<h1>
							<?php require_once("includes/logo.inc.php"); ?>
						</h1>
					</div>
					<div id="nav">
						<?php require_once("includes/menu.inc.php"); ?>
						<br class="clear" />
					</div>
				</div>
				
				<div id="main">
					<div id="sidebar">
						<?php require_once("includes/sidebar.inc.php"); ?>
					</div>
					<div id="content">
						<div id="box1">
							<h2>
								Welcome to Website
							</h2>
							<p>
								<?php require_once("includes/slideshow.inc.php"); ?>
							</p>
						</div>
						
						<br class="clear" />
					</div>
					<br class="clear" />
				</div>
			</div>
			<div id="copyright">
				<?php require_once("includes/footer.inc.php"); ?>
			</div>
		</div>
    </body>
</html>
