<?php

	if(empty($_POST)) { header("location: index.php"); exit; }

	$errors = array();

	//General Validation

	if(empty($_POST["nm"]))
		$errors[] = "Name was empty!";

	if(empty($_POST["email"]))
		$errors[] = "Email was empty!";

	if(empty($_POST["phone"]))
		$errors[] = "Phone was empty!";
	if( ! ctype_digit($_POST["phone"]) || strlen($_POST["phone"]) != 10)
		$errors[] = "Phone must be valid 10 digits!";

	if(empty($_POST["sub"]))
		$errors[] = "Subject was empty!";

	if(empty($_POST["msg"]))
		$errors[] = "Message was empty!";


	//Show Errors, If Any

	if( ! empty($errors) ) {
		echo "<b>Error(s):</b><hr />";
		foreach($errors as $e) {
			echo $e."<br />";
		}
		exit;
	}


	//Data Entry
	require_once("classes/dbo.class.php");
	$q = "insert into feedback(fb_nm, fb_email, fb_phone, fb_subject, fb_msg,fb_date) values('".$_POST["nm"]."','".$_POST["email"]."','".$_POST["phone"]."','".$_POST["sub"]."', '".$_POST["msg"]."','".date('Y-m-d')."')";
	$db->dml($q);

	header("location: feedback.php"); 
?>